from fastapi.params import Form
from fastapi import FastAPI,Request, Query, File, UploadFile
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from markupsafe import re
import starlette.status as status
from starlette.middleware.sessions import SessionMiddleware
from starlette.responses import RedirectResponse, Response
import starlette.status as status
from typing import Optional 
from dbcontroller import DBController
import sqlite3

app = FastAPI()

app.mount("/static",StaticFiles(directory="static"),"static")

templates = Jinja2Templates("templates")

# SessionMiddleware secret key
app.add_middleware(SessionMiddleware, secret_key="asdfghjkl")


db = DBController("app.db")


@app.get("/", response_class=HTMLResponse)
def index(request:Request):
    return templates.TemplateResponse("page1.html",{"request":request})


@app.post("/register",response_class=HTMLResponse)
def create_post(request:Request, name:str = Form(...), contact_number:str = Form(...), email:str = Form(...), date:str = Form(...), time:str = Form(...), whom_to_meet:str = Form(...),  purpose:str = Form(...), reason:str = Form(...), photo:str = Form(...)):
    data = {"name":name, "contact_number":contact_number, "email":email, "date":date, "time":time, "whom_to_meet":whom_to_meet,  "purpose":purpose, "reason":reason, "photo":photo}
    if(db.insert("register1",data=data)):
        return templates.TemplateResponse("register.html",{"request":request,"msg":"Registered successfully"})
    return templates.TemplateResponse("register.html",{"request":request,"msg":"Unable to register"})

@app.post("/",response_class=HTMLResponse)
def index_post(request:Request, email:str = Form(...), password:str=Form(...)):
    users = db.executeQueryWithParams("select * from users where email =? and password=?", [email, password])[0]
    request.session.setdefault("isLogin", True)
    request.session.setdefault('email', users['email'])
    request.session.setdefault('role', users['role'])
    role = users['role']
    print(role)
    if role==1:
        return RedirectResponse("/FFdashboard", status_code=status.HTTP_302_FOUND)
    else:
        return RedirectResponse("/Tdashboard", status_code=status.HTTP_302_FOUND)
        
    if(len(users)==0):
        return templates.TemplateResponse("login2.html",{"request":request, "msg":"invalid email and password" })
    return RedirectResponse("/FFdashboard",status_code=status.HTTP_302_FOUND)

@app.post("/teacherlogin",response_class=HTMLResponse)
def teacher_login(request:Request, email:str = Form(...), password:str=Form(...)):
    users = db.executeQueryWithParams("select * from addteachers where email =? and password=?", [email, password])[0]
    print(users)
    print("users are being printed")
    request.session.setdefault("isLogin", True)
    request.session.setdefault('email', users['email'])
    request.session.setdefault('role', 2)
    request.session.setdefault('name', users['name'])
    request.session.setdefault('department', users['department'])
    request.session.setdefault('contact_number', users['contact_number'])
    
    if(len(users)==0):
        return templates.TemplateResponse("login2.html",{"request":request, "msg":"invalid email and password" })
    
    return RedirectResponse("/Tdashboard", status_code=status.HTTP_302_FOUND)

@app.get("/Tdashboard", response_class=HTMLResponse)
def create(request:Request):
    isLogin = request.session.get('isLogin')
    role = request.session.get('role')
    name = request.session.get('name')
    email = request.session.get('email')
    department = request.session.get('department')
    contact_number = request.session.get('contact_number')
    print(status)
    if role == 2:
        #orders = db.executeQuery("select * from register1 where whom_to_meet =?", [name])
            # Connect to the database
        conn = sqlite3.connect("app.db")
        cursor = conn.cursor()
        department_name= name+" - "+department
        pfp = db.executeQueryWithParams("select * from addteachers where email =?", [email])[0]
        # Fetch the video records for the specified course
        cursor.execute("SELECT * FROM register1 where whom_to_meet=?", (department_name,))
        orders = cursor.fetchall()
        print(orders)
        conn.close()
        return templates.TemplateResponse("Tdashboard.html",{"request":request, "orders": orders, "name": name, "department": department, "contact_number":contact_number, "email":email, "pfp": pfp})
    else:
        return "Unauthorized acess"


@app.get("/FFdashboard", response_class=HTMLResponse)
def create(request:Request):
    isLogin = request.session.get('isLogin')
    role = request.session.get('role')
    email = request.session.get('email')
    print(role)
    if role == 1:
        #if status != None:
        #db.executeQueryWithParams("UPDATE register1 set status = ? where id =? ",[status,id])
        conn = sqlite3.connect("app.db")
        cursor = conn.cursor()
        admin= cursor.execute("SELECT * FROM users where email=?", (email,))
        admin_meeting = db.executeQueryWithParams("select * from register1 where email =?", [email])
        admin_meeting_personal = db.executeQueryWithParams("select * from register1 where email =? and purpose =?", [email,"Personal"])
        admin_meeting_business = db.executeQueryWithParams("select * from register1 where email =? and purpose =?", [email,"Business"])
        orders = db.executeQuery("select * from register1")
        return templates.TemplateResponse("FFdashboard.html",{"request":request, "orders": orders, "admin_meeting": admin_meeting, "admin_meeting_personal": admin_meeting_personal, "admin_meeting_business":  admin_meeting_business, "email":email, "admin": admin})
    else:
        return "Unauthorized Access"
    
@app.post("/authorize", response_class=HTMLResponse)
def authorize(request:Request, status:str=Query(None),id:int=Query(None)):
    print(status)
    if status != None:
        db.executeQueryWithParams("UPDATE register1 set status = ? where id =? ",[status,id])
    orders = db.executeQuery("select * from register1")
    return templates.TemplateResponse("FFdashboard.html",{"request":request, "orders": orders})

   
@app.get("/logout", response_class=HTMLResponse)
def logout(request: Request):
    request.session.clear()
    return RedirectResponse("/", status_code=status.HTTP_302_FOUND)
    



@app.get("/Fregister", response_class=HTMLResponse)
def create(request:Request):
    isLogin = request.session.get('isLogin')
    role = request.session.get('role')
    if role == 1:
        return templates.TemplateResponse("Fregister.html",{"request":request})
    else:
        return "Unauthorized acess"
    
@app.post("/Fregister",response_class=HTMLResponse)
def create_post(request:Request, name:str = Form(...),department:str = Form(...),contact_number:int = Form(...), date_of_birth:str = Form(...), email:str = Form(...), teachers_id:int = Form(...), password:str = Form(...), photo: UploadFile = File(...)):
    file_path = "static/images/" + photo.filename
    with open(file_path, "wb") as f:
        f.write(photo.file.read())
    
    
    data = {"name":name, "department":department, "contact_number":contact_number, "date_of_birth":date_of_birth, "email":email,"teachers_id":teachers_id, "password":password, "photo":file_path}
    if(db.insert("addteachers",data=data)):
        return templates.TemplateResponse("Fregister.html",{"request":request,"msg":"Account created successfully!!"})
    return templates.TemplateResponse("Fregister.html",{"request":request,"msg":"Unable to create account"})
    
    
@app.get("/login1", response_class=HTMLResponse)
def create(request:Request):
    return templates.TemplateResponse("login1.html",{"request":request})    
        

@app.get("/others", response_class=HTMLResponse)
def create(request:Request):
    teacher_meeting = db.executeQuery("select * from register1")
    teacher_meeting_personal = db.executeQueryWithParams("select * from register1 where purpose =?", ["Personal"])
    teacher_meeting_business = db.executeQueryWithParams("select * from register1 where purpose =?", ["Business"])
    return templates.TemplateResponse("others.html",{"request":request, "teacher_meeting":teacher_meeting, "teacher_meeting_personal":teacher_meeting_personal, "teacher_meeting_business":teacher_meeting_business})

@app.get("/login2", response_class=HTMLResponse)
def create(request:Request):
    return templates.TemplateResponse("login2.html",{"request":request})

@app.get("/page1", response_class=HTMLResponse)
def create(request:Request):
    return templates.TemplateResponse("page1.html",{"request":request})

@app.get("/visitor1", response_class=HTMLResponse)
def create(request:Request):
    return templates.TemplateResponse("visitor1.html",{"request":request})

@app.get("/register", response_class=HTMLResponse)
def create(request:Request):
    teachers = db.executeQuery("select * from addteachers")
    return templates.TemplateResponse("register.html",{"request":request, "teachers": teachers})

@app.get("/check-status", response_class=HTMLResponse)
def check_status(request:Request):
    return templates.TemplateResponse("check-status.html",{"request":request})

@app.post("/check-status",response_class=HTMLResponse)
def check_status(request:Request, phone:str = Form(...)):
    status_check = db.executeQueryWithParams("select * from register1 where contact_number =?", [phone])
    response = templates.TemplateResponse("check-status.html", {"request": request, "status_check": status_check})
    return response